from .stepone import step1
from .steptwo import step2
from .stepthree import step3
from .stepfour import step4
from .stepfive import step5
from .test_train_split import splitCancer, splitNormal

def dataProcess(homepath,names,cancerpath,smoothed_cancer,smoothed_normal):
	step1(homepath,names)
	step2(homepath)
	step3(homepath)
	step4(homepath,cancerpath,smoothed_cancer)
	step5(homepath,names,smoothed_cancer,smoothed_normal)
	splitCancer(homepath,names)
	splitNormal(homepath,names)


