from .featSelect import featSelect
from .dataProcess import dataProcess
from .binarymerge import btrain, btest
from .multimerge import mtrain, mtest
from .upsampling_train_data import upsampled


def binary_merge(names,homepath):
	btrain(names,homepath)
	btest(names,homepath)


def multi_merge(names,homepath):
	mtrain(names,homepath)
	mtest(names,homepath)